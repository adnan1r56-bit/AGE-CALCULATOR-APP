AGE CALCULATOR — ANDROID PROJECT
================================
یہ Android Studio project ہے۔ اس میں آپ کی Age Calculator کی English، Modern Professional اسکرین شامل ہے۔ حساب فون پر مقامی طور پر ہوتا ہے؛ انٹرنیٹ یا Excel کی ضرورت نہیں۔

مطابقت:
- Minimum Android: Android 8.0 (API 26)
- Android 8 سے نئے Android ورژنز کے لیے تیار
- Offline کام کرتا ہے
- فون کی تاریخ کے مطابق عمر شمار کرتا ہے
- Date of Birth مستقبل کی تاریخ نہیں ہو سکتی

APK بنانے کا طریقہ:
1. کمپیوٹر پر Android Studio انسٹال کریں۔
2. Android Studio کھولیں اور Open منتخب کریں۔
3. اس ZIP سے نکالا ہوا AgeCalculator فولڈر منتخب کریں (وہ فولڈر جس میں settings.gradle.kts موجود ہے)۔
4. Gradle Sync مکمل ہونے دیں۔ پہلی مرتبہ Android Gradle Plugin اور Android SDK 35 ڈاؤن لوڈ ہو سکتے ہیں۔
5. Build > Build Bundle(s) / APK(s) > Build APK(s) منتخب کریں۔
6. APK یہاں ملے گی: app/build/outputs/apk/debug/app-debug.apk
7. APK فون میں منتقل کریں، اسے کھولیں، اور اگر پوچھا جائے تو اس فائل مینیجر کے لیے Install unknown apps کی اجازت دیں۔

اہم:
- یہ مکمل Android Studio source project ہے، پہلے سے compile شدہ APK نہیں۔ اس ماحول میں Android SDK/Gradle build setup موجود نہیں، اس لیے APK یہاں compile نہیں کی گئی۔
- Google Play پر شائع کرنے کے لیے الگ signed release build اور Play Console کی ضرورت ہوتی ہے۔
